#ifndef SELECT_SORT_H
#define SELECT_SORT_H

#include "item.h"

void sort(Item *a, int lo, int hi);

#endif /*SELECT_SORT_H*/