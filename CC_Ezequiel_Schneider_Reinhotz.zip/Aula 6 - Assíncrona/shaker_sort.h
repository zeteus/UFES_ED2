#ifndef SHAKER_SORT_H
#define SHAKER_SORT_H

#include "item.h"

void sort(Item *a, int lo, int hi);

#endif /*SHAKER_SORT_H*/