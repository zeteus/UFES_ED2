#ifndef INSERT_SORT_H
#define INSERT_SORT_H

#include "item.h"

void sort(Item *a, int lo, int hi);

#endif /*INSERT_SORT_H*/