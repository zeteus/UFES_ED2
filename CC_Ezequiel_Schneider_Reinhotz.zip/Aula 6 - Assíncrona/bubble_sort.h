#ifndef BUBBLE_SORT_H
#define BUBBLE_SORT_H

#include "item.h"

void sort(Item *a, int lo, int hi);

#endif /*BUBBLE_SORT_H*/